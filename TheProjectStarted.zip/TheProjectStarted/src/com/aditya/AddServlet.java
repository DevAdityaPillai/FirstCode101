package com.aditya;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AddServlet extends HttpServlet{

	//wanna perform any operation we need method
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		//service is a method that goes with the server life cycle.
		int i = Integer.parseInt(req.getParameter("num1"));
		int j = Integer.parseInt(req.getParameter("num2"));
		
		int k = i+j;
		k = k*k;
		
		
		//RequestDispatcher is an interface
		
		/*req.setAttribute("k", k);
		
		RequestDispatcher rd = req.getRequestDispatcher("sq");
		rd.forward(req, res);
		
		*/
		
		
		//2nd method for the redirect method to call a servlet from another servlet.
		
		//res.sendRedirect("sq?k="+k);
		
		//3rd method, session
		
		HttpSession session = req.getSession();
		session.setAttribute("k", k);
		res.sendRedirect("sq");
		
	}
//user tries to find the and servlet and so is to combine the index html form action to the servlet 
// which is implemented using deployment descriptor.
	
	//this servlet creates a page on the browser and sends data using res object. (Servlet to client)
	
	
	
	

}

